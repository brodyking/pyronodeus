	<!-- header - start -->
	<head>
		<meta charset="utf-8">
		<title><?php if(isset($pageTitle)){echo $pageTitle;} ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="style.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
	</head>
	<!-- header - end -->
